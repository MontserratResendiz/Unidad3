package com.example.practica1u2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    String nombre = "Juan Perez", loging = "Juan", password = "123";

    private EditText log, pass;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        log =findViewById(R.id.usuario);
        pass =findViewById(R.id.pass);

    }

    public void validar(View view){
        Intent Saludo = new Intent(MainActivity.this, Saludo.class);
        Intent error = new Intent(MainActivity.this, Incorrecto.class);
        String l=log.getText().toString();
        String p=pass.getText().toString();

        if(l.equals(loging) && p.equals(password)){
            Saludo.putExtra("nombre", nombre);
            startActivity(Saludo);
        }
        else
            startActivity(error);

    }


}