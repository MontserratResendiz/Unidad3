package com.example.practica1u2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Saludo extends AppCompatActivity {

    private TextView saludoM;
            Bundle datos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saludo2);

        saludoM=findViewById(R.id.saludoM);
        datos= getIntent().getExtras();
        saludoM.setText(datos.getString("nombre"));

    }

    public void Regresar(View view){
        finish();
    }

}