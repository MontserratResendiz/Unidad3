package com.example.docs;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class Inicio extends AppCompatActivity {

    private EditText impor, etHoraR, etMinR, etUbiAct, etUbiNue;
    private Button actRecordatorio, bGuardarT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio4);

        impor = findViewById(R.id.impor);
        etHoraR = findViewById(R.id.etHorasR);
        etMinR = findViewById(R.id.etMinR);
        actRecordatorio = findViewById(R.id.actRecordatorio);
        etUbiAct = findViewById(R.id.etubiAct);
        etUbiNue = findViewById(R.id.etubiNue);
        bGuardarT = findViewById(R.id.bGuardarT);

        String archivos[] = fileList();

        if(ArchivoExiste(archivos, "Notas.txt")){
            try{
                InputStreamReader archivo = new InputStreamReader(openFileInput("Notas.txt"));
                BufferedReader br = new BufferedReader(archivo);
                String linea = br.readLine();
                String notasCompleta = "";

                while (linea != null){
                    notasCompleta = notasCompleta + linea + "\n";
                    linea = br.readLine();
                }
                br.close();
                archivo.close();
                impor.setText(notasCompleta);

            }catch (IOException e){

            }
        }
//--------------------------- ALARMA / RECORDATORIO ------------------------------------------//
        actRecordatorio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int hour = Integer.parseInt(etHoraR.getText().toString());
                int minute = Integer.parseInt(etMinR.getText().toString());

                Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM);
                intent.putExtra(AlarmClock.EXTRA_HOUR,hour);
                intent.putExtra(AlarmClock.EXTRA_MINUTES,minute);

                if (hour <= 24 && minute <= 60){
                    startActivity(intent);
                }

            }
        });

//-------------------- USO DE GOOGLE MAPS ---------------------------------//

        bGuardarT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ubiActual = etUbiAct.getText().toString().trim();
                String ubiDestino = etUbiNue.getText().toString().trim();

                if(ubiActual.equals("") && ubiDestino.equals("")){
                    Toast.makeText(getApplicationContext(),"Enter both location",Toast.LENGTH_SHORT).show();
                }else{
                    DisplayTrack(ubiActual,ubiDestino);
                }

            }
        });

    }

    private void DisplayTrack(String ubiActual, String ubiDestino) {

        try {
            Uri uri = Uri.parse("https://www.google.co.in/maps/dir/" + ubiActual + "/" + ubiDestino);

            Intent intent = new Intent(Intent.ACTION_VIEW,uri);
            intent.setPackage("com.google.android.apps.maps");
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

        }catch (ActivityNotFoundException e){
            Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps.maps");
            Intent intent = new Intent(Intent.ACTION_VIEW,uri);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
    }

//-------------------------- GUARDADO DE NOTAS EN LA PANTAÑA PRINCIPAL ----------------------------------//

    private boolean ArchivoExiste(String archivos [], String NombreArchivo){
        for(int i = 0; i < archivos.length; i++)
            if(NombreArchivo.equals(archivos[i]))
                return true;
        return false;
    }

    public void Guardar(View view){

        try{
            OutputStreamWriter archivo = new OutputStreamWriter(openFileOutput("Notas.txt", Activity.MODE_PRIVATE));
            archivo.write(impor.getText().toString());
            archivo.flush();
            archivo.close();
        }catch (IOException e){

        }

        Toast.makeText(this,"Nota guardada con exito",Toast.LENGTH_SHORT).show();

    }

//--------------------------- BOTONES / CAMBIO ENTRE PESTAÑAS -------------------------//

    public void NotasPestaña (View view){

        Intent Notas = new Intent(Inicio.this, Notas.class);

        startActivity(Notas);

    }

    public void MenuQRR(View view){
        Intent MenuQr = new Intent(Inicio.this, MenuQr.class);
        startActivity(MenuQr);
    }

    public void HorariosPestaña(View view){
        Intent Horarios = new Intent(Inicio.this, Horarios.class);

        startActivity(Horarios);
    }

    public void ContraPestana(View view){
        Intent Pass = new Intent(Inicio.this, Pass.class);
        startActivity(Pass);
    }


}