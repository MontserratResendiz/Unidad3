package com.example.docs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private EditText etContraseña;
    private Button LogOut, botonMenu;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LogOut = findViewById(R.id.logOut);
        mAuth = FirebaseAuth.getInstance();
        botonMenu = findViewById(R.id.botonMenu);

        LogOut.setOnClickListener(view -> {
            mAuth.signOut();
            startActivity(new Intent(MainActivity.this, Login.class));
        });

    }

    @Override
    protected void onStart(){
        super.onStart();
        FirebaseUser user = mAuth.getCurrentUser();

        if(user == null){
            startActivity(new Intent(MainActivity.this, Login.class));
        }
    }

    public void BotMenuIni(View view){
        startActivity(new Intent(MainActivity.this, Inicio.class));
    }

    public void DesPes(View view){
        startActivity(new Intent(MainActivity.this, Desarrollador.class));
    }

}