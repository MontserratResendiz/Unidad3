package com.example.docs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MenuQr extends AppCompatActivity {

    private Button lectorQR, generatorQR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_qr);

        generatorQR = findViewById(R.id.genUnQR);
        lectorQR = findViewById(R.id.leerUnQR);

    }

    public void GenQR(View view){
        Intent ContactosQR = new Intent(MenuQr.this, ContactosQR.class);
        startActivity(ContactosQR);
    }

    public void LeerQR(View view){
        Intent LeerQr = new Intent(MenuQr.this, LeerQr.class);
        startActivity(LeerQr);
    }

}