package com.example.docs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Pass extends AppCompatActivity {

    private Button continueB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pass);

        continueB = findViewById(R.id.continueB);

        continueB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Contrasenas = new Intent(Pass.this, Contrasenas.class);
                startActivity(Contrasenas);
            }
        });

    }
}