package com.example.docs;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SingUp extends AppCompatActivity {

    EditText emialSing, passSing;
    Button regisSing, loginHere;

    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sing_up);

        emialSing = findViewById(R.id.emailSing);
        passSing = findViewById(R.id.passSing);
        regisSing = findViewById(R.id.regisSing);
        loginHere = findViewById(R.id.LoginHere);

        mAuth = FirebaseAuth.getInstance();

        regisSing.setOnClickListener(view -> {
            createUser();
        });

        loginHere.setOnClickListener(view -> {
            startActivity(new Intent(SingUp.this, Login.class));
        });

    }

    private void createUser(){
        String email = emialSing.getText().toString();
        String pass = passSing.getText().toString();

        if(TextUtils.isEmpty(email)){
            emialSing.setError("Email canont be empty");
            emialSing.requestFocus();
        }else if (TextUtils.isEmpty(pass)){
            passSing.setError("Password canont be empty");
            passSing.requestFocus();
        }else{
            mAuth.createUserWithEmailAndPassword(email,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        Toast.makeText(SingUp.this,"User registered successfull",Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(SingUp.this, Login.class));
                    }else{
                        Toast.makeText(SingUp.this,"Error" + task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
}